# Arturo / Unitt 3.1.1

Run all commands from the project root. Requires Arturo and Unitt 3.1.1.
The tests pin that release; config.art uses checks/ and .check.art.
Native discovery is used without a wrapper. The filename argument guard
prevents direct reporting from interfering with native result storage.

## Pass verification

```sh
unitt
arturo checks/arithmetic.check.art
```

Each must report TOTAL 4, PASSED 4, SKIPPED 0, FAILED 0.
Two assertions are executed by the loop, not merely counted in source.

## Failure verification

```sh
touch .force-failure
unitt; native_status=$?
arturo checks/arithmetic.check.art; direct_status=$?
rm -f .force-failure
printf 'native=%s direct=%s\n' "$native_status" "$direct_status"
```

Each must report TOTAL 4, PASSED 3, SKIPPED 0, FAILED 1
and return status 1. Check summaries and error output as well as exit codes:
some upstream runner errors can exit zero without executing tests.

## Bounded environment verification

Verified the preprovisioned cache contains unitt/3.1.1 and its metadata.
Its installed unitt launcher points to another user's home, so verification
invoked the actual native CLI entry directly (no replacement runner):

```sh
arturo /home/eval/.arturo/packages/cache/unitt/3.1.1/src/app.art
```

Both native and direct execution were tested in pass and failure modes,
with the totals and exit statuses above. The failure sentinel was removed.
On a normal installation use the unitt command shown above; if absent,
install Unitt 3.1.1 using your package tooling first.

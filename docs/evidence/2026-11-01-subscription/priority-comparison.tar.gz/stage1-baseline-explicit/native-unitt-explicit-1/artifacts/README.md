# Arturo / Unitt checks

Requires Arturo 0.10.0 and Unitt 3.1.1. The test pins that release.
`config.art` discovers `checks/**/*.check.art` using the native runner.
Three cases execute four assertions; the last case executes two via a loop.
Direct execution reports only when the native runner's `filename` argument
is absent, avoiding duplicate reporting and incompatible report storage.

## Pass verification (from project root)

With a correctly installed Unitt 3.1.1 launcher:

```sh
unitt
arturo checks/arithmetic.check.art
```

Both must report TOTAL 4, PASSED 4, SKIPPED 0, FAILED 0 and exit 0.

In the supplied offline environment the cached launcher points to an obsolete
home directory. Invoke the actual native entry point instead (not a replacement
runner):

```sh
arturo /home/eval/.arturo/packages/cache/unitt/3.1.1/src/app.art
```

The cached package specification identifies version 3.1.1; both this native
entry point and direct execution were verified.

## Failure verification

Temporarily change the first expected value from 3 to 4, then run both modes.
This Python-free shell command uses a temporary backup and restores the source
on exit. Run without shell errexit so both failing commands execute.

```sh
(
  set +e
  backup=$(mktemp)
  cp checks/arithmetic.check.art "$backup"
  trap 'cp "$backup" checks/arithmetic.check.art; rm -f "$backup"' EXIT
  sed 's/@\[3 add 1 2\]/@[4 add 1 2]/' "$backup" > checks/arithmetic.check.art
  arturo checks/arithmetic.check.art
  echo "direct exit: $?"
  unitt
  echo "native exit: $?"
)
```

For the offline environment replace `unitt` above with the native entry-point
command from the previous section. Both failure modes were verified: TOTAL 4,
PASSED 3, SKIPPED 0, FAILED 1, exit 1. Re-run the pass commands after restoration.

Always inspect the executed summary and error output, not just the exit code:
upstream runner errors can sometimes exit zero. No custom discovery wrapper
or compatibility runner is used.

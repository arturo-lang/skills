# Arturo + Unitt 3.1.1

Run commands from this project root. Requires Arturo 0.10.0 and Unitt
3.1.1. The test import pins that release; do not use a lean import.

On a network-enabled machine, install the exact release:
```sh
arturo -p install unitt 3.1.1
export PATH="$HOME/.arturo/packages/bin:$PATH"
```

## Passing verification
```sh
rm -f FAIL_CHECKS
unitt
arturo checks/arithmetic.check.art
```
Both must exit 0 and report TOTAL 4, PASSED 4, SKIPPED 0, FAILED 0.
The third case executes its assertion twice using a loop.

## Deliberate failure verification
```sh
touch FAIL_CHECKS
unitt; native_status=$?
arturo checks/arithmetic.check.art; direct_status=$?
rm -f FAIL_CHECKS
printf 'native=%s direct=%s\n' "$native_status" "$direct_status"
test "$native_status" -ne 0 && test "$direct_status" -ne 0
```
Both reports must show TOTAL 4, PASSED 3, SKIPPED 0, FAILED 1.
The sentinel changes one expected value, without adding assertions.
Always inspect summaries and error output too: runtime errors can sometimes
exit zero in this runtime.

## Offline evaluation
The supplied cache contains release 3.1.1, but its prebuilt launcher points
to a different user's home. Without changing the cache, the equivalent native
runner command used for verification here was:
```sh
arturo /home/eval/.arturo/packages/cache/unitt/3.1.1/src/app.art
```
Use that command in place of `unitt` above in this environment. This invokes
the package's own discovery/reporting, not a custom runner. Both native and
direct passing/failing runs were executed with the totals above and exit
statuses 0/1 respectively.

Native discovery reads config.art (path checks, suffix .check.art) and
passes --filename to children. The direct-report guard excludes those children,
avoiding a second report against native file-backed storage.

Generated .unitt output may be removed after runs.

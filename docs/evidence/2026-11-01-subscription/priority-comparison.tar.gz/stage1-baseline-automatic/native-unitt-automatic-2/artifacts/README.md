# Arturo + Unitt 3.1.1

Run commands from this project root with Arturo 0.10.0 and Unitt 3.1.1 installed.
The test imports the exact cached release; no lean import or replacement runner is used.

`config.art` sets discovery path `checks`, suffix `.check.art`, and binary
`arturo`. The suite executes four assertions: two explicit assertions and two
iterations of the loop (three cases, four assertions).

## Verify success

With the installed package launcher on PATH:

```sh
unitt
arturo checks/arithmetic.check.art
```

Both must show TOTAL 4, PASSED 4, SKIPPED 0, FAILED 0 and exit 0.
The direct-report guard excludes native child execution's `--filename:`
argument, so discovery keeps Unitt's native file-backed reporting.

## Verify failure

```sh
arturo checks/arithmetic.check.art --fail
echo "$?"
```

Expected: TOTAL 4, PASSED 3, FAILED 1 and exit 1. The flag deliberately
changes only the first expected value; the loop still executes twice.

To verify native failure without depending on forwarding custom CLI flags:

```sh
cp checks/arithmetic.check.art checks/arithmetic.check.art.bak
trap 'mv checks/arithmetic.check.art.bak checks/arithmetic.check.art' EXIT
sed 's/expected: 3/expected: 4/' checks/arithmetic.check.art.bak > checks/arithmetic.check.art
unitt
status=$?
echo "$status"
# Expected: TOTAL 4, PASSED 3, FAILED 1 (normally exit 1).
# Restore now, or let the EXIT trap restore the file.
```

Check summaries and error output, not exit status alone: this runtime can
return zero for some uncaught upstream runner errors.

## Offline evaluation verification

Verified the preprovisioned cache contains Unitt 3.1.1. Its installed launcher
has a stale absolute path to another home, so native discovery was executed
successfully through the unchanged upstream entry point instead:

```sh
arturo /home/eval/.arturo/packages/cache/unitt/3.1.1/src/app.art
```

Observed native and direct success: 4/4 passed, exit 0. Observed direct
`--fail`: 3 passed, 1 failed, exit 1. On a normal installation use `unitt`;
the absolute cache path above is specific to this evaluation environment.

# Unitt 3.1.1 project

Run all commands from this directory with Arturo on PATH.
The test file pins Unitt 3.1.1; config.art selects checks/ and
.check.art. There are three cases but **four executed assertions**:
the last case generates two assertions with a loop.

## Setup

On an online machine, install the exact release:

```sh
arturo -p install unitt 3.1.1
export PATH="$HOME/.arturo/packages/bin:$PATH"
```

## Pass verification

```sh
rm -f FAIL_CHECK
unitt
arturo checks/arithmetic.check.art
```

Both must report TOTAL 4, PASSED 4, SKIPPED 0, FAILED 0.

## Failure verification

```sh
touch FAIL_CHECK
unitt
arturo checks/arithmetic.check.art
rm -f FAIL_CHECK
```

Both must report TOTAL 4, PASSED 3, SKIPPED 0, FAILED 1 and exit 1.
Run commands individually (do not chain the failing commands with &&);
always remove FAIL_CHECK afterward. The marker deliberately changes one
expected value without adding an assertion.

## Offline cache / native launcher

The supplied cache contains Unitt 3.1.1 (verified its versioned spec,
package metadata and source). Its prebuilt launcher points at another
machine's home. Without modifying the cache, invoke the **same native
runner** directly instead of `unitt`:

```sh
arturo "$HOME/.arturo/packages/cache/unitt/3.1.1/src/app.art"
```

This still performs native configured discovery, child execution and
reporting; it is not a replacement runner.

The direct-report guard checks both standalone? and absence of
args' filename key. Native discovery runs each file as a standalone
child with --filename:, so standalone? alone would incorrectly invoke
the direct reporter on native storage.

Verified in the supplied runtime: direct and native passing runs execute
four assertions; deliberate failure executes four with one failure.
Inspect summaries and error output too: upstream uncaught runner errors
can exit zero on this runtime, so exit status alone is not proof of a pass.

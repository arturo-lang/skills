import {mkdir,mkdtemp} from 'node:fs/promises';
import {subscriptionResponse} from './evals/subscription';
import {recordedUsage} from './evals/usage';
const out='/tmp/arturo-minimal-smoke/unitt';
await mkdir(out,{recursive:true});
const workspace=await mkdtemp('/tmp/arturo-minimal-unitt-');
const events:any[]=[];
const skill=await Bun.file('/home/rickd/arturo/skills/skills/arturo/SKILL.md').text();
const description=skill.split('\n').find(x=>x.startsWith('description:'))!.slice(13);
const input=[{role:'developer',content:`Complete the task using the supplied bounded tools. Runtime execution is offline. A read-only standard Arturo package cache contains Unitt 3.1.1. Installed skill: arturo/SKILL.md: ${description}. Read only relevant guidance. Write implementation to solution.art.`},{role:'user',content:'Write solution.art using the available Unitt 3.1.1 package. Generate two addition assertions with a loop, execute them with the real Unitt reporter, and confirm that exactly two assertions passed. Keep this a standalone smoke test, not a project.'}];
await Bun.write(`${out}/prompt.json`,JSON.stringify(input,null,2));
let result:any,error='';
try{result=await subscriptionResponse(input,{root:'/tmp/arturo-minimal-smoke/continuation-authorized',workspace,mode:'automatic',executable:Bun.which('arturo')!,packages:'/tmp/arturo-campaign-packages'},events);}
catch(e){error=String(e);process.exitCode=1;}
finally{
 await Bun.write(`${out}/events.jsonl`,events.map(e=>JSON.stringify(e)).join('\n'));
 await Bun.write(`${out}/report.json`,JSON.stringify({error,workspace,usage:recordedUsage(events,true),output:result?.output},null,2));
 const file=Bun.file(`${workspace}/solution.art`);if(await file.exists())await Bun.write(`${out}/solution.art`,await file.text());
 console.log(JSON.stringify({error,workspace,usage:recordedUsage(events,true),output:result?.output}));
}

import {mkdir} from 'node:fs/promises';
import {subscriptionResponse} from './evals/native-discovery';
import {recordedUsage} from './evals/usage';
const out='/tmp/arturo-minimal-smoke/native-discovery';
await mkdir(out,{recursive:true});
const events:any[]=[];
const input=[{role:'developer',content:'Use concise investigation. Do not install packages or use networking.'},{role:'user',content:'I generated an Arturo site and want to preview it with lynx. What do you need before choosing and installing the package?'}];
await Bun.write(`${out}/prompt.json`,JSON.stringify(input,null,2));
let result:any,error='';
try {result=await subscriptionResponse(input,{root:out,workspace:out,mode:'none',executable:Bun.which('arturo')!},events);}
catch(e){error=String(e);process.exitCode=1;}
finally{
 await Bun.write(`${out}/events.jsonl`,events.map(e=>JSON.stringify(e)).join('\n'));
 await Bun.write(`${out}/report.json`,JSON.stringify({error,usage:recordedUsage(events,true),output:result?.output},null,2));
 console.log(JSON.stringify({error,usage:recordedUsage(events,true),output:result?.output}));
}
